<?php
// Evitar errores de codificación en caracteres especiales
header('Content-Type: text/html; charset=utf-8');

// Incluir archivo de conexión
include_once('../php/conexion.php');

$mensaje = "";

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($conexion) && $conexion) {
    $nombre = mysqli_real_escape_string($conexion, $_POST['nombre']);
    $correo = mysqli_real_escape_string($conexion, $_POST['correo']);
    $tema   = mysqli_real_escape_string($conexion, $_POST['tema_interes']);

    $sql = "INSERT INTO registros (nombre, correo, tema_interes) VALUES ('$nombre', '$correo', '$tema')";

    if (mysqli_query($conexion, $sql)) {
        $mensaje = "<div style='color: #1b5e20; background: #c8e6c9; padding: 12px; border-radius: 4px; font-weight: bold; margin-bottom: 15px;'>¡Registro guardado con éxito en la base de datos!</div>";
    } else {
        $mensaje = "<div style='color: #b71c1c; background: #ffcdd2; padding: 12px; border-radius: 4px; font-weight: bold; margin-bottom: 15px;'>Error al guardar: " . mysqli_error($conexion) . "</div>";
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Práctica 1_2 - Desarrollo Web Integrado</title>
    <link rel="stylesheet" href="../css/vintage.css">
</head>
<body>

    <header>
        <h1>Desarrollo de Aplicaciones Web</h1>
        <p>Práctica 1_2 • Arquitectura, Lenguajes, Metodología UWE y Base de Datos</p>
    </header>

    <!-- Menú con navegación corregida a todas las secciones -->
   <!-- Menú con enlace a la Práctica 1 y navegación interna -->
    <nav>
        <!-- Enlace hacia la Práctica 2 -->
        <a href="../../practica2/suma.php" style="background-color: var(--coffee-dark); border: 1px solid var(--coffee-accent);">→ Ir a Práctica 2</a>

        <a href="#introduccion">1. Introducción</a>
        <a href="#clasificacion">2. Tipos de Apps</a>
        <a href="#arquitecturas">3. Arquitecturas</a>
        <a href="#lenguajes">4. LDC vs LDS</a>
        <a href="#metodologia-uwe">5. Metodología UWE</a>
        <a href="#seguridad">6. Seguridad</a>
        <a href="#registro">7. Formulario BD</a>
    </nav>

    <main>
        <!-- 1. Introducción -->
        <section id="introduccion" class="paper-card">
            <h2>1. Introducción a las Aplicaciones Web</h2>
            <p>
                Una aplicación web es un sistema de información en el que una amplia cantidad de datos volátiles y altamente estructurados son consultados, procesados y analizados mediante navegadores. Su característica clave es la alta interacción con el usuario mediante interfaces claras.
            </p>
        </section>

        <!-- 2. Clasificación -->
        <section id="clasificacion" class="paper-card">
            <h2>2. Clasificación de Aplicaciones Web</h2>
            <div class="table-wrapper">
                <table>
                    <thead>
                        <tr>
                            <th>Tipo de Aplicación</th>
                            <th>Descripción</th>
                            <th>Ejemplos</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td><strong>Informacionales</strong></td>
                            <td>Difusión de información personalizada o general.</td>
                            <td>Blogs, portales de noticias</td>
                        </tr>
                        <tr>
                            <td><strong>Interactivas y Transaccionales</strong></td>
                            <td>Interacción directa y realización de operaciones financieras o datos.</td>
                            <td>Banca electrónica, e-commerce</td>
                        </tr>
                        <tr>
                            <td><strong>Trabajo Colaborativo</strong></td>
                            <td>Entornos para interacción distribuida entre usuarios.</td>
                            <td>Foros, plataformas C2C</td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </section>
<!-- 3. Arquitecturas con Imagen -->
        <section id="arquitecturas" class="paper-card">
            <h2>3. Arquitecturas de las Aplicaciones Web</h2>
            <div class="table-wrapper">
                <table>
                    <thead>
                        <tr>
                            <th>Arquitectura</th>
                            <th>Niveles</th>
                            <th>Detalles Clave</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td><strong>Dos Capas</strong>[cite: 2]</td>
                            <td>Cliente y Servidor[cite: 2]</td>
                            <td>Usa proceso de envío PostBack[cite: 2]. Recomendada para aplicaciones no muy pesadas[cite: 2].</td>
                        </tr>
                        <tr>
                            <td><strong>Tres Capas</strong>[cite: 2]</td>
                            <td>Presentación, Negocio y Datos[cite: 2]</td>
                            <td>La más utilizada actualmente[cite: 2]. Separa navegador, scripts de lógica y base de datos[cite: 2].</td>
                        </tr>
                    </tbody>
                </table>
            </div>

            <!-- Imagen de Arquitecturas -->
            <div class="image-box">
                <img src="../imagenes/images (2).jpg" alt="Esquema de Arquitecturas Web">
                <p><em>Figura 1: Representación de arquitecturas en dos y tres capas.</em></p>
            </div>
        </section>

        <!-- 4. Lenguajes LDC y LDS con Imagen -->
        <section id="lenguajes" class="paper-card">
            <h2>4. Lenguajes LDC y LDS</h2>
            <div class="table-wrapper">
                <table>
                    <thead>
                        <tr>
                            <th>Tipo</th>
                            <th>Lugar de Ejecución</th>
                            <th>Ejemplos</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td><strong>Lado del Cliente (LDC)</strong>[cite: 2]</td>
                            <td>Se ejecutan en el navegador del usuario[cite: 2]. El código es accesible[cite: 2].</td>
                            <td>HTML, CSS, JavaScript[cite: 2]</td>
                        </tr>
                        <tr>
                            <td><strong>Lado del Servidor (LDS)</strong>[cite: 2]</td>
                            <td>Se interpretan en el servidor web (Apache) devolviendo HTML[cite: 2].</td>
                            <td>PHP, ASP.net, JSP, Java[cite: 2]</td>
                        </tr>
                    </tbody>
                </table>
            </div>

            <!-- Imagen de Lenguajes -->
            <div class="image-box">
                <img src="../imagenes/images (1).jpg" alt="Lenguajes Cliente y Servidor">
                <p><em>Figura 2: Interacción entre lenguajes del lado del cliente y servidor.</em></p>
            </div>
        </section>

        <!-- 5. Metodología UWE con Imagen -->
        <section id="metodologia-uwe" class="paper-card">
            <h2>5. Metodología UWE (UML-based Web Engineering)</h2>
            <p>
                UWE es una metodología detallada orientada al proceso de autoría de aplicaciones web adaptativas. Propuesta por Nora Koch en el año 2000, se basa en el estándar UML para cubrir todo el ciclo de vida del desarrollo.
            </p>

            <!-- Imagen de Modelos y Fases UWE -->
            <div class="image-box">
                <img src="../imagenes/caratula_programacion_v2.png" alt="Modelos y Fases de la Metodología UWE">
                <p><em>Figura 3: Modelos y fases del ciclo de desarrollo UWE.</em></p>
            </div>

            <h3>Pasos Clave del Modelado UWE</h3>
            <ul class="vintage-list">
                <li><strong>Análisis de Requisitos:</strong> Captura los requisitos funcionales mediante casos de uso.</li>
                <li><strong>Diseño Conceptual:</strong> Define el modelo del dominio o de contenido.</li>
                <li><strong>Diseño Navegacional:</strong> Modela la estructura y espacio de navegación.</li>
                <li><strong>Diseño de Presentación:</strong> Representa la interfaz de usuario y vistas de interacción.</li>
            </ul>
        </section>
       
        <!-- 6. Seguridad -->
        <section id="seguridad" class="paper-card">
            <h2>6. Aspectos de Seguridad Web</h2>
            <ul class="vintage-list">
                <li><strong>PC del Usuario:</strong> Navegadores actualizados, parches de SO y antivirus[cite: 2].</li>
                <li><strong>Servidor Web:</strong> Asegurar el SO, servidor web (Apache) y control de acceso a BD[cite: 2].</li>
                <li><strong>Información en Tránsito:</strong> Cifrado de datos mediante SSL y criptografía[cite: 2].</li>
            </ul>
        </section>

        <!-- 7. Formulario MySQL -->
        <section id="registro" class="paper-card">
            <h2>7. Registro de Interés (Conexión e Inserción MySQL)</h2>
            <p>Rellena los campos para realizar una inserción de datos directa en XAMPP:</p>

            <?php echo $mensaje; ?>

            <form action="" method="POST" style="display: flex; flex-direction: column; gap: 15px; max-width: 500px;">
                <div>
                    <label for="nombre" style="font-weight: bold; display: block; margin-bottom: 5px;">Nombre Completo:</label>
                    <input type="text" id="nombre" name="nombre" required style="width: 100%; padding: 8px; border: 1px solid var(--border-color); border-radius: 4px;">
                </div>

                <div>
                    <label for="correo" style="font-weight: bold; display: block; margin-bottom: 5px;">Correo Electrónico:</label>
                    <input type="email" id="correo" name="correo" required style="width: 100%; padding: 8px; border: 1px solid var(--border-color); border-radius: 4px;">
                </div>

                <div>
                    <label for="tema_interes" style="font-weight: bold; display: block; margin-bottom: 5px;">Tema de Interés:</label>
                    <select id="tema_interes" name="tema_interes" required style="width: 100%; padding: 8px; border: 1px solid var(--border-color); border-radius: 4px;">
                        <option value="Metodología UWE">Metodología UWE</option>
                        <option value="Arquitectura de 3 Capas">Arquitectura de 3 Capas</option>
                        <option value="Lenguajes LDS/LDC">Lenguajes LDS / LDC</option>
                        <option value="Seguridad Web">Seguridad Web</option>
                    </select>
                </div>

                <button type="submit" style="background: var(--coffee-medium); color: white; border: none; padding: 10px 18px; font-weight: bold; cursor: pointer; border-radius: 4px; width: fit-content;">
                    Guardar Registro en BD
                </button>
            </form>
        </section>
    </main>

    <footer>
        <p>&copy; <?php echo date('Y'); ?> • Práctica 1_2 Integrada | Servidor Apache & PHP en XAMPP</p>
    </footer>

</body>
</html>