<?php
$servidor  = "localhost";
$usuario   = "root";
$password  = ""; 
$bd_nombre = "practica_db";

$conexion = @mysqli_connect($servidor, $usuario, $password, $bd_nombre);

if (!$conexion) {
    $estado_conexion = "Servidor Activo (Falta crear BD 'practica_db')";
} else {
    $estado_conexion = "Conexión Exitosa a BD 'practica_db'";
}
?>