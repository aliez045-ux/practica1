<?php
header('Content-Type: text/html; charset=utf-8');

$res_tabla = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Verificar que los campos contengan valores numéricos
    if (isset($_POST['tabla_base']) && isset($_POST['limite']) && $_POST['tabla_base'] !== '' && $_POST['limite'] !== '') {
        
        $tabla_base = floatval($_POST['tabla_base']);
        $limite     = intval($_POST['limite']);

        if ($limite >= 1) {
            $res_tabla = "<strong>Tabla del $tabla_base (hasta el $limite):</strong><br><br>";
            for ($i = 1; $i <= $limite; $i++) {
                $mult = $tabla_base * $i;
                $res_tabla .= "$tabla_base × $i = <strong>$mult</strong><br>";
            }
        } else {
            $res_tabla = "<span style='color: #b71c1c;'>Por favor ingresa un límite igual o mayor a 1.</span>";
        }
    } else {
        $res_tabla = "<span style='color: #b71c1c;'>Por favor completa ambos campos.</span>";
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Práctica 2 - Tabla de Multiplicar</title>
    <link rel="stylesheet" href="css/vintage.css">
</head>
<body>
    <header>
        <h1>Práctica 2: Operaciones Separadas</h1>
        <p>Módulo de Tablas Dinámicas</p>
    </header>

    <nav>
        <a href="../practica%201_2/html/index.php">← Práctica 1_2</a>
        <a href="suma.php">1. Sumar</a>
        <a href="ordenar.php">2. Ordenar Números</a>
        <a href="tabla.php" class="activo">3. Tabla de Multiplicar</a>
    </nav>

    <main>
        <section class="paper-card">
            <h2>Tabla de Multiplicar con Límite</h2>
            <form action="tabla.php" method="POST">
                <div class="form-group">
                    <label for="tabla_base">Tabla del número:</label>
                    <input type="number" step="any" id="tabla_base" name="tabla_base" required>
                </div>
                <div class="form-group">
                    <label for="limite">Límite (Hasta qué número multiplicar):</label>
                    <input type="number" id="limite" name="limite" min="1" value="10" required>
                </div>
                <button type="submit">Generar Tabla</button>
            </form>

            <?php if ($res_tabla != ""): ?>
                <div class="resultado-box"><?php echo $res_tabla; ?></div>
            <?php endif; ?>
        </section>
    </main>

    <footer>
        <p>&copy; <?php echo date('Y'); ?> • Práctica 2 | Tablas</p>
    </footer>
</body>
</html>