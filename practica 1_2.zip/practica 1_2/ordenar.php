<?php
header('Content-Type: text/html; charset=utf-8');

$res_suma = "";
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $num1 = floatval($_POST['num1']);
    $num2 = floatval($_POST['num2']);
    $suma = $num1 + $num2;
    $res_suma = "Resultado: $num1 + $num2 = <strong>$suma</strong>";
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Práctica 2 - Sumar</title>
    <link rel="stylesheet" href="css/vintage.css">
</head>
<body>
    <header>
        <h1>Práctica 2: Operaciones Separadas</h1>
        <p>Módulo de Suma</p>
    </header>

    <nav>
        <a href="../practica%201_2/html/index.php">← Práctica 1_2</a>
        <a href="suma.php" class="activo">1. Sumar</a>
        <a href="ordenar.php">2. Ordenar Números</a>
        <a href="tabla.php">3. Tabla de Multiplicar</a>
    </nav>

    <main>
        <section class="paper-card">
            <h2>Suma de Dos Números</h2>
            <form action="" method="POST">
                <div class="form-group">
                    <label for="num1">Primer Número:</label>
                    <input type="number" step="any" id="num1" name="num1" required>
                </div>
                <div class="form-group">
                    <label for="num2">Segundo Número:</label>
                    <input type="number" step="any" id="num2" name="num2" required>
                </div>
                <button type="submit">Calcular Suma</button>
            </form>

            <?php if ($res_suma != ""): ?>
                <div class="resultado-box"><?php echo $res_suma; ?></div>
            <?php endif; ?>
        </section>
    </main>

    <footer>
        <p>&copy; <?php echo date('Y'); ?> • Práctica 2 | Suma</p>
    </footer>
</body>
</html>